////// FASHION FOR WOMEN  /////////////////////////////////////////////////////////
var longwaiting = 2000;
var shortwaiting = 500;

var story1 = [
    //maxine == A
    //whyatt ==



    {s: "A", m: "I had the best night of MY LIFE!", wait: shortwaiting},
    {s: "B", m: "Me too.", wait: shortwaiting},
    {s: "B", m: "You’re a special one Maxine.", wait: longwaiting},
    {s: "A", m: "*kiss*", wait: shortwaiting},
    {s: "B", m: "Gotta go...Text you later.", wait: 3000},
    {s: "system", m: "1 hour later", wait: 500},
    {s: "A", m: "OMG I can’t believe my eyes!", wait: longwaiting},
    {s: "A", m: "HOW DARE YOU!", wait: shortwaiting},    
    {s: "A", m: "I just saw you in front of that hotel on Sunset.", wait: longwaiting},
    {s: "A", m: "I can’t believe you would do this.", wait: longwaiting},
    {s: "A", m: "How could you not tell me?", wait: longwaiting},
    {s: "B", m: "...", next: "end"}

];

